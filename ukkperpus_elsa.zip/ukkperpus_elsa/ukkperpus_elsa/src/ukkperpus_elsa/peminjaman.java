package ukkperpus_elsa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class peminjaman extends javax.swing.JFrame {
    Connection konek = koneksi.koneksiDb();
     private void getDataBuku() {
    try {
        String query = "SELECT BukuID, Judul FROM buku";
        PreparedStatement pst = konek.prepareStatement(query);
        ResultSet rs = pst.executeQuery();
        
        // Clear jComboBox2
        jComboBox1.removeAllItems();
        
        // Add data from the buku table to jComboBox2
        while (rs.next()) {
            String bukuID = rs.getString("BukuID");
            String judul = rs.getString("Judul");
            jComboBox1.addItem(bukuID + " - " + judul);
        }
    } catch (SQLException e) {
        System.err.println("Error fetching book data: " + e.getMessage());
    }
     }
      private void getDataUser() {
    try {
        String query = "SELECT UserID, NamaLengkap FROM user";
        PreparedStatement pst = konek.prepareStatement(query);
        ResultSet rs = pst.executeQuery();
        
        // Bersihkan jComboBox1
        jComboBox1.removeAllItems();
        
        // Tambahkan data user ke jComboBox1
        while (rs.next()) {
            String userID = rs.getString("UserID");
            String namaLengkap = rs.getString("NamaLengkap");
            jComboBox1.addItem(userID + " - " + namaLengkap);
        }
    } catch (SQLException e) {
        System.err.println("Error saat mengambil data user: " + e.getMessage());
    }
}
private void tampilDataUser() {
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("UserID");
    model.addColumn("Email");
    model.addColumn("NamaLengkap");
    model.addColumn("Alamat");
    jTable1.setModel(model);

    try {
        Statement stat = konek.createStatement();
        ResultSet data = stat.executeQuery("SELECT * FROM user");
        while (data.next()) {
            model.addRow(new Object[]{
                data.getString("UserID"),
                data.getString("Email"),
                data.getString("NamaLengkap"),
                data.getString("Alamat")
            });
        }
    } catch (SQLException e) {
        System.err.println("Terjadi Kesalahan : " + e);
    }
}
private void tampilDataBuku() {
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("BukuID");
    model.addColumn("Judul");
    model.addColumn("Penulis");
    model.addColumn("Penerbit");
    model.addColumn("TahunTerbit");
    jTable1.setModel(model);

    try {
        Statement stat = konek.createStatement();
        ResultSet data = stat.executeQuery("SELECT * FROM buku");
        while (data.next()) {
            model.addRow(new Object[]{
                data.getString("BukuID"),
                data.getString("Judul"),
                data.getString("Penulis"),
                data.getString("Penerbit"),
                data.getString("TahunTerbit")
            });
        }
    } catch (SQLException e) {
        System.err.println("Terjadi Kesalahan : " + e);
    }
}
private void tampilDataPeminjaman(){
     DefaultTableModel model = new DefaultTableModel();
     model.addColumn("PeminjamanID");
     model.addColumn("UserID");
     model.addColumn("BukuID");
     model.addColumn("TanggalPeminjaman");
     model.addColumn("TanggalPengembalian");
     model.addColumn("StatusPeminjaman");
     jTable1.setModel(model);
     
     try {
         Statement stat = konek.createStatement();
         ResultSet data = stat.executeQuery("SELECT * FROM peminjaman");
         while (data.next()) {
             model.addRow(new Object[]{
                 data.getString("PeminjamanID"),
                 data.getString("UserID"),
                 data.getString("BukuID"),
                 data.getString("TanggalPeminjaman"),
                 data.getString("TanggalPengembalian"),
                 data.getString("StatusPeminjaman")
             });
             jTable1.setModel(model);
         }
     } catch (Exception e) {
         System.err.println("Terjadi Kesalahan : " + e);
     }
     
 }
    public peminjaman() {
        initComponents();
       tampilDataUser();
       tampilDataBuku();
       tampilDataPeminjaman();
         getDataUser();
         getDataBuku();
    }




    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jTextField4 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("PEMINJAMAN");

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("PeminjamanID");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("UserID");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("BukuID");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("TanggalPeminjaman");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("TanggalPengembalian");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("StatusPeminjaman");

        jButton1.setText("SAVE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("UPDATE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("DELETE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("SEARCH");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "PeminjamanID", "UserID", "BukuID", "TanggalPeminjaman", "TanggalPengembalian", "StatusPeminjaman"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jButton5.setText("kembali");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel6)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jLabel3))
                        .addGap(37, 37, 37)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE)
                            .addComponent(jTextField2)
                            .addComponent(jTextField3)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jDateChooser2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                                .addComponent(jDateChooser1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(70, 70, 70))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 598, Short.MAX_VALUE))
                .addGap(19, 19, 19))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jButton2)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3)))
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton5)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(237, 237, 237))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
          try {
        // Mendapatkan nilai dari input komponen
        String peminjamanID = jTextField1.getText();
        String userID = jComboBox1.getSelectedItem().toString().split(" - ")[0]; // Mengambil UserID dari pilihan combo box
        String bukuID = jTextField2.getText().toString().split(" - ")[0]; // Mengambil BukuID dari pilihan combo box
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String tanggalPeminjaman = sdf.format(jDateChooser1.getDate());
        String tanggalPengembalian = sdf.format(jDateChooser2.getDate());
        String statusPeminjaman = jTextField2.getText();

        // Query untuk menyimpan data peminjaman ke dalam database
        String query = "INSERT INTO peminjaman (PeminjamanID, UserID, BukuID, TanggalPeminjaman, TanggalPengembalian, StatusPeminjaman) "
                     + "VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement pst = konek.prepareStatement(query);
        pst.setString(1, peminjamanID);
        pst.setString(2, userID);
        pst.setString(3, bukuID);
        pst.setString(4, tanggalPeminjaman);
        pst.setString(5, tanggalPengembalian);
        pst.setString(6, statusPeminjaman);

        // Eksekusi query
        int rowsInserted = pst.executeUpdate();
        if (rowsInserted > 0) {
            JOptionPane.showMessageDialog(null, "Data peminjaman berhasil disimpan!");
            // Refresh tabel data peminjaman
            tampilDataPeminjaman();
        } else {
            JOptionPane.showMessageDialog(null, "Gagal menyimpan data peminjaman!");
        }
    } catch (SQLException e) {
        System.err.println("Terjadi Kesalahan : " + e);
    } 
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
 try {
        // Ambil nilai dari input komponen
        String peminjamanID = jTextField1.getText();
        String userID = jComboBox1.getSelectedItem().toString().split(" - ")[0]; // Mengambil UserID dari pilihan combo box
        String bukuID = jTextField2.getText().toString().split(" - ")[0]; // Mengambil BukuID dari pilihan combo box
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String tanggalPeminjaman = sdf.format(jDateChooser1.getDate());
        String tanggalPengembalian = sdf.format(jDateChooser2.getDate());
        String statusPeminjaman = jTextField2.getText();

        // Query untuk melakukan update data peminjaman di dalam database
        String query = "UPDATE peminjaman SET UserID = ?, BukuID = ?, TanggalPeminjaman = ?, TanggalPengembalian = ?, StatusPeminjaman = ? WHERE PeminjamanID = ?";
        PreparedStatement pst = konek.prepareStatement(query);
        pst.setString(1, userID);
        pst.setString(2, bukuID);
        pst.setString(3, tanggalPeminjaman);
        pst.setString(4, tanggalPengembalian);
        pst.setString(5, statusPeminjaman);
        pst.setString(6, peminjamanID);

        // Eksekusi query
        int rowsUpdated = pst.executeUpdate();
        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(null, "Data peminjaman berhasil diperbarui!");
            // Refresh tabel data peminjaman
            tampilDataPeminjaman();
        } else {
            JOptionPane.showMessageDialog(null, "Gagal memperbarui data peminjaman!");
        }
    } catch (SQLException e) {
        System.err.println("Terjadi Kesalahan : " + e);
    }           
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
 try {
        // Ambil nilai PeminjamanID dari input
        String peminjamanID = jTextField1.getText();

        // Query untuk menghapus data peminjaman dari database
        String query = "DELETE FROM peminjaman WHERE PeminjamanID = ?";
        PreparedStatement pst = konek.prepareStatement(query);
        pst.setString(1, peminjamanID);

        // Eksekusi query
        int rowsDeleted = pst.executeUpdate();
        if (rowsDeleted > 0) {
            JOptionPane.showMessageDialog(null, "Data peminjaman berhasil dihapus!");
            // Refresh tabel data peminjaman
            tampilDataPeminjaman();
        } else {
            JOptionPane.showMessageDialog(null, "Gagal menghapus data peminjaman!");
        }
    } catch (SQLException e) {
        System.err.println("Terjadi Kesalahan : " + e);
    }                             
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
      halaman_utama panggil = new halaman_utama();
               panggil.show();
                       
               this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        try {
            SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
            int baris=jTable1.getSelectedRow();
              
            if (baris != -1){
                jTextField1.setText(jTable1.getValueAt(baris, 0).toString());
                jDateChooser1.setDate(fm.parse(jTable1.getValueAt(baris, 1).toString()));
                jDateChooser2.setDate(fm.parse(jTable1.getValueAt(baris, 1).toString()));
                jTextField2.setText(jTable1.getValueAt(baris, 2).toString());
                jComboBox1.setSelectedItem(jTable1.getValueAt(baris, 3).toString());
                jTextField3.setText(jTable1.getValueAt(baris, 5).toString());
            }
            jTextField4.setEnabled(false);
            
        } catch (Exception e){
            System.err.println("Terjadi Kesalahan : " + e);
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
          try {
        // Ambil nilai dari input pencarian
        String searchTerm = jTextField3.getText();

        // Query untuk melakukan pencarian data peminjaman berdasarkan PeminjamanID
        String query = "SELECT * FROM peminjaman WHERE PeminjamanID = ?";
        PreparedStatement pst = konek.prepareStatement(query);
        pst.setString(1, searchTerm);

        // Eksekusi query
        ResultSet rs = pst.executeQuery();

        // Buat model tabel untuk menampilkan hasil pencarian
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("PeminjamanID");
        model.addColumn("UserID");
        model.addColumn("BukuID");
        model.addColumn("TanggalPeminjaman");
        model.addColumn("TanggalPengembalian");
        model.addColumn("StatusPeminjaman");
        jTable1.setModel(model);

        // Tampilkan hasil pencarian di tabel
        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("PeminjamanID"),
                rs.getString("UserID"),
                rs.getString("BukuID"),
                rs.getString("TanggalPeminjaman"),
                rs.getString("TanggalPengembalian"),
                rs.getString("StatusPeminjaman")
            });
        }

        // Jika tidak ada hasil dari pencarian, tampilkan pesan
        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(null, "Data tidak ditemukan.");
        }
    } catch (SQLException e) {
        System.err.println("Terjadi Kesalahan : " + e);
    }                              

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
         DefaultTableModel model = new DefaultTableModel();
     model.addColumn("PeminjamanID");
     model.addColumn("UserID");
     model.addColumn("BukuID"); 
     model.addColumn("TanggalPeminjaman");
      model.addColumn("TanggalPengembalian");
       model.addColumn("StatusPeminjaman");
      
          jTable1.setModel(model);
          
          try{
              Statement stat = konek.createStatement();
              ResultSet data = stat.executeQuery("SELECT * FROM peminjaman");
              while (data.next()) {
                  model.addRow(new Object[] {
                data.getString("PeminjamanID"),
                 data.getString("UserID"),
                 data.getString("BukuID"),
                 data.getString("TanggalPeminjaman"),
                 data.getString("TanggalPengembalian"),
                 data.getString("StatusPeminjaman"),
              });
             jTable1.setModel(model);
              }
          } catch (Exception e) {
              System.err.println("Terjadi kesalahan;"+ e );
          }
                           
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new peminjaman().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    // End of variables declaration//GEN-END:variables
}
